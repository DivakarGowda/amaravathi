<header>
                <!--Top Header Start -->
                <div class="top">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 col-xs-12">
                                <ul class="list-inline float-left icon">
                                    <li class="list-inline-item"><a href="#"><i class="icofont icofont-phone"></i> Call us for Order :+91 9986606320</a></li>
                                </ul>
                                <!-- Header Social Start -->
                                <ul class="list-inline float-right icon">
                                    <li class="list-inline-item"><a href="shopping-cart.html"><i class="icofont icofont-cart-alt"></i> Cart</a></li>
                                    <!--<li class="list-inline-item dropdown">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icofont icofont-ui-user"></i> My Account</a>
                                        <ul class="dropdown-menu dropdown-menu-right drophover" aria-labelledby="dropdownMenuLink">
                                            <li class="dropdown-item"><a href="login.html">Login</a></li>
                                            <li class="dropdown-item"><a href="register.html">Register</a></li>
                                        </ul>
                                    </li>-->
                                    <li class="list-inline-item">
                                        <ul class="list-inline social">
                                            <li class="list-inline-item"><a href="https://www.facebook.com/spheretheme/" target="_blank"><i class="icofont icofont-social-facebook"></i></a></li>
                                            <li class="list-inline-item"><a href="https://twitter.com/spheretheme/" target="_blank"><i class="icofont icofont-social-twitter"></i></a></li>
                                            <li class="list-inline-item"><a href="https://plus.google.com/" target="_blank"><i class="icofont icofont-social-google-plus"></i></a></li>
                                            <li class="list-inline-item"><a href="https://www.instagram.com/" target="_blank"><i class="icofont icofont-social-instagram"></i></a></li>
                                            <li class="list-inline-item"><a href="https://in.pinterest.com/" target="_blank"><i class="icofont icofont-social-pinterest"></i></a></li>
                                            <li class="list-inline-item"><a href="https://www.youtube.com/" target="_blank"><i class="icofont icofont-social-youtube-play"></i></a></li>
                                        </ul>
                                    </li>
                                </ul>
                                <!-- Header Social End -->
                            </div>
                        </div>
                    </div>
                </div>
                <!--Top Header End -->

                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <!-- Logo Start  -->
                            <div id="logo">
                                <a href="index.php"><img id="logo_img" class="img-fluid" src="assets/images/logo/logo-white.png" alt="logo" title="logo" /></a>
                            </div>
                            <!-- Logo End  -->
                        </div>

                        <div class="col-md-7 col-sm-6 col-xs-12 paddleft">
                            <!-- Main Menu Start  -->
                            <div id="menu">	
                                <nav class="navbar navbar-expand-md">
                                    <div class="navbar-header">
                                        <span class="menutext d-block d-md-none">Menu</span>
                                        <button data-target=".navbar-ex1-collapse" data-toggle="collapse" class="btn btn-navbar navbar-toggler" type="button"><i class="icofont icofont-navigation-menu"></i></button>
                                    </div>
                                    <div class="collapse navbar-collapse navbar-ex1-collapse padd0">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item"><a href="index.php">HOME</a>
                                                <!--<div class="dropdown-menu">
                                                    <div class="dropdown-inner">
                                                        <ul class="list-unstyled">
                                                            <li><a href="index-1.html">Home Page One</a></li>
                                                            <li><a href="index-2.html">Home page Two</a></li>
                                                            <li><a href="index-3.html">home page Three</a></li>
                                                            <li><a href="index-onepage.html">One Page</a></li>
                                                        </ul>
                                                    </div>
                                                </div>--->
                                            </li>
                                            <li class="nav-item"><a href="about.php">about us</a></li>
                                            <li class="nav-item dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Our Menu</a>
                                                <div class="dropdown-menu">
                                                    <div class="dropdown-inner">
                                                        <ul class="list-unstyled">
                                                            <li><a href="andhra-style-menu.php">Andhra Style Menu</a></li>
                                                            <li><a href="chinese-starter-menu.php">Chinese Starter Menu</a></li>
															<li><a href="north-indian-menu.php">North-Indian Menu</a></li>
															<li><a href="coastal-style-menu.php">Coastal Style Menu</a></li>
															<li><a href="seafood-menu.php">Sea Food Menu</a></li>
															<li><a href="arabianstyle-menu.php">Arabian Style Menu</a></li>
															<li><a href="tandoori-egg-menu.php">Tandoori/Egg Menu</a></li>
															<li><a href="chicken-mutton-rice-menu.php">Chicken/Mutton/Rice Menu</a></li>
															<li><a href="fruitjuice-milkshakes-menu.php">Fruit Juice & Milk Shakes Menu</a></li>
															<li><a href="soups-salads-menu.php">Soups & Salads Menu</a></li>
															<li><a href="icecream-desserts-menu.php">Icecream & Desserts Menu</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                            <!----<li class="nav-item dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages</a>
                                                <div class="dropdown-menu">
                                                    <div class="dropdown-inner">
                                                        <ul class="list-unstyled">
                                                            <li><a href="reservation.html">Reservation</a></li>
                                                            <li><a href="shop.html">Shop</a></li>
                                                            <li><a href="shop-details.html">Shop Details</a></li>
                                                            <li><a href="shopping-cart.html">Shopping Cart</a></li>
                                                            <li><a href="search.html">Search</a></li>
                                                            <li><a href="login.html">Login</a></li>
                                                            <li><a href="register.html">Register</a></li>
                                                            <li><a href="forgot-password.html">Forgot Password</a></li>
                                                            <li><a href="thank-you.html">Thank You</a></li>
                                                            <li><a href="404.html">404</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>---->
                                            <li class="nav-item dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Our Blog</a>
                                                <div class="dropdown-menu">
                                                    <div class="dropdown-inner">
                                                        <ul class="list-unstyled">
                                                            <li><a href="blog.php">Special</a></li>
                                                           <li><a href="blog-details.php">Details</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="nav-item dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">contact us</a>
                                                <div class="dropdown-menu">
                                                    <div class="dropdown-inner">
                                                        <ul class="list-unstyled">
                                                            <li><a href="contact-us.php">Enquiry</a></li>
                                                            <!---<li><a href="contact-us-2.html">contact us 2</a></li>
                                                            <li><a href="contact-us-3.html">contact us 3</a></li>--->
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
											 <li class="nav-item"><a href="https://www.google.com/maps/place/Amaravathi+Gardenia+Andhra+Style+Multi+Cuisine+Restaurant/@13.2574432,77.7134077,15z/data=!4m2!3m1!1s0x0:0x84bd9641d3a8225e?sa=X&ved=2ahUKEwj_lJWN_N_dAhUIo48KHbHSA7AQ_BIwCnoECAoQCw" target="_blank">map</a></li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                            <!-- Main Menu End -->
                        </div>
                        <div class="col-md-2 col-sm-12 col-xs-12 button-top paddleft">
                            <a class="btn-primary btn" href='reservation.html'>Book Your Table</a>
                        </div>
                    </div>
                </div>
            </header>